var mongodb = require('mongodb');
var uri = "mongodb://wdn:U7z5b&9a*3$#sHc2@ds047592.mongolab.com:47592/wdn";
exports.connect = function(callback){
    mongodb.MongoClient.connect(uri, callback);
};

